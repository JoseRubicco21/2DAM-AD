package com.ad_ud2_at2.services.menu.exceptions;

public class InvalidOptionException extends Exception {

    public InvalidOptionException(String msg){
        super(msg);
    }
}
