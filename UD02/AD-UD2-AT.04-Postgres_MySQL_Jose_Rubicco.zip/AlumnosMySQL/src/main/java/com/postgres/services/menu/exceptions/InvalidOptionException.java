package com.postgres.services.menu.exceptions;

public class InvalidOptionException extends Exception {

    public InvalidOptionException(String msg){
        super(msg);
    }
}
