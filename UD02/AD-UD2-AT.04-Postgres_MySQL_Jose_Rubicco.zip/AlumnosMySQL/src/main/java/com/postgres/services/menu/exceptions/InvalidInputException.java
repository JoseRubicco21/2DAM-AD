package com.postgres.services.menu.exceptions;

public class InvalidInputException extends Exception {

    public InvalidInputException(String msg){
        super(msg);
    }
}
