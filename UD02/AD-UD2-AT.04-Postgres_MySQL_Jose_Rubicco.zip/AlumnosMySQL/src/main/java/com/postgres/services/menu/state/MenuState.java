package com.postgres.services.menu.state;

public enum MenuState {
    ACTIVE,
    INACTIVE,
}
