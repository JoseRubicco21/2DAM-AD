package com.ad_ud2_at2.services.menu.exceptions;

public class InvalidInputException extends Exception {

    public InvalidInputException(String msg){
        super(msg);
    }
}
