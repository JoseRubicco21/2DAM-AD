package com.ad_ud2_at2.services.menu.state;

public enum MenuState {
    ACTIVE,
    INACTIVE,
}
