package models.mage;

public enum Hechizo {
    ADIVINACION,
    NECROMANCIA,
    PRIOMANCIA,
    INVOCACION
}
