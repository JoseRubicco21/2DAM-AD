package menu;

public enum MenuState {
    ACTIVE,
    INACTIVE,
}
