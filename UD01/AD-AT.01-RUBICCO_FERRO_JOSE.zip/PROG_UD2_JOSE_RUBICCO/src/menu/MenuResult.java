package menu;
// We could add another MenuResult like "Unwanted" or "Unexpected" 
// and move the program on a different direction.
public enum MenuResult {
    CONTINUE,
    EXIT,
}
