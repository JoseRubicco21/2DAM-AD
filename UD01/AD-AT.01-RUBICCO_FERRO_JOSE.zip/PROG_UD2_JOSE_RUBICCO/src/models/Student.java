package models;

public class Student extends Person{

    @Override
    public String toString() {
        return "Student []";
    }
    
    
}
