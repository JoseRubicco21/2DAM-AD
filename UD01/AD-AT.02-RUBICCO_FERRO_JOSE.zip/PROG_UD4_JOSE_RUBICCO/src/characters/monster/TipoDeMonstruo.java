package characters.monster;

public enum TipoDeMonstruo {
    OGRO,
    TROLL,
    ESPECTRO
}
